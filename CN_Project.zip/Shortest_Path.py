import heapq
import random

class Pheromone:
    def __init__(self, initial_value=1.0, evaporation_rate=0.5):
        self.value = initial_value
        self.evaporation_rate = evaporation_rate

    def evaporate(self):
        self.value *= (1 - self.evaporation_rate)

    def deposit(self, amount):
        self.value += amount

class Graph:
    def __init__(self):
        self.vertices = {}
        self.pheromones = {}

    def add_edge(self, u, v, weight):
        u = u.lower()
        v = v.lower()
        if u not in self.vertices:
            self.vertices[u] = []
        if v not in self.vertices:
            self.vertices[v] = []
        self.vertices[u].append((v, weight))  # Append (neighbor, weight) tuple
        self.vertices[v].append((u, weight))  # Append (neighbor, weight) tuple
        self.pheromones[(u, v)] = Pheromone()
        self.pheromones[(v, u)] = self.pheromones[(u, v)]

    def bfs(self, start, end):
        visited = set()
        queue = [[start]]
        if start == end:
            return [start], "Breadth-First Search"
        while queue:
            path = queue.pop(0)
            node = path[-1]
            if node not in visited:
                neighbours = self.vertices.get(node, [])
                for neighbour, _ in neighbours:
                    new_path = list(path)
                    new_path.append(neighbour)
                    queue.append(new_path)
                    if neighbour == end:
                        return new_path, "Breadth-First Search"
                visited.add(node)
        return None, "Breadth-First Search"

    def dijkstra(self, start, end):
        queue = [(0, start, [])]
        visited = set()
        while queue:
            (cost, node, path) = heapq.heappop(queue)
            if node not in visited:
                path = path + [node]
                if node == end:
                    return path, "Dijkstra's Algorithm"
                visited.add(node)
                for neighbor, edge_cost in self.vertices.get(node, []):
                    heapq.heappush(queue, (cost + edge_cost, neighbor, path))
        return None, "Dijkstra's Algorithm"

    def astar(self, start, end, heuristic):
        open_list = [(heuristic[start], 0, start, [])]
        closed_set = set()
        while open_list:
            _, g, node, path = heapq.heappop(open_list)
            if node == end:
                return path + [node], "A* Algorithm"
            if node in closed_set:
                continue
            closed_set.add(node)
            for neighbor, edge_cost in self.vertices.get(node, []):
                heapq.heappush(open_list, (g + edge_cost + heuristic[neighbor], g + edge_cost, neighbor, path + [node]))
        return None, "A* Algorithm"

    class Swarm:
        def __init__(self, n, graph, start, end, alpha=1.0, beta=2.0, max_iterations=100):
            self.agents = [SwarmAgent(start, graph, alpha, beta) for _ in range(n)]
            self.graph = graph
            self.start = start
            self.end = end
            self.max_iterations = max_iterations
            self.heuristic = {node: 1 for node in graph.vertices}  # Constant heuristic of 1 for all nodes

        def find_shortest_path(self):
            for _ in range(self.max_iterations):
                for agent in self.agents:
                    next_node = agent.move(self.end, self.heuristic)
                    if next_node == self.end:
                        return self.reconstruct_path(agent.current_node)
                self.update_pheromones()

            return None

        def reconstruct_path(self, end_node):
            path = [end_node]
            curr_node = end_node
            while curr_node != self.start:
                neighbors = [neighbor for neighbor, _ in self.graph.vertices[curr_node]]
                max_pheromone = max(
                    (self.graph.pheromones.get((curr_node, neighbor), Pheromone()).value for neighbor in neighbors),
                    default=0
                )
                for neighbor in neighbors:
                    if self.graph.pheromones.get((curr_node, neighbor), Pheromone()).value == max_pheromone:
                        curr_node = neighbor
                        path.append(curr_node)
                        break
            path.reverse()
            return path


        def update_pheromones(self):
            for edge, pheromone in self.graph.pheromones.items():
                pheromone.evaporate()
            for agent in self.agents:
                path = [self.start, agent.current_node]
                while len(path) > 1:
                    u, v = path.pop(0), path[0]
                    self.graph.pheromones[(u, v)].deposit(1.0)

class SwarmAgent:
    def __init__(self, start, graph, alpha=1.0, beta=2.0):
        self.current_node = start
        self.graph = graph
        self.alpha = alpha  # Pheromone weight
        self.beta = beta  # Heuristic weight

    def move(self, destination, heuristic):
        neighbors = [neighbor for neighbor, _ in self.graph.vertices[self.current_node]]
        probabilities = []
        for neighbor in neighbors:
            pheromone = self.graph.pheromones[(self.current_node, neighbor)].value
            heuristic_value = heuristic[neighbor]
            probability = pheromone ** self.alpha * (1.0 / heuristic_value) ** self.beta
            probabilities.append(probability)
        total_probability = sum(probabilities)
        probabilities = [p / total_probability for p in probabilities]
        next_node = random.choices(neighbors, weights=probabilities, k=1)[0]
        self.current_node = next_node
        return next_node


last_algorithm_index = -1  # Initialize the index of the last used algorithm

def evaluate_algorithm(graph, source, destination):
    global last_algorithm_index

    num_edges = sum(len(edges) for edges in graph.vertices.values())
    num_vertices = len(graph.vertices)

    # Define a list of available algorithms
    algorithms = ["A* Algorithm", "Swarm Algorithm", "Dijkstra's Algorithm", "Breadth-First Search"]

    # Update the index of the last used algorithm
    last_algorithm_index = (last_algorithm_index + 1) % len(algorithms)

    # Select the next algorithm
    selected_algorithm = algorithms[last_algorithm_index]

    if selected_algorithm == "Swarm Algorithm" and num_vertices <= 1000 and num_edges <= 10000:
        swarm = graph.Swarm(10, graph, source, destination)
        return swarm.find_shortest_path(),

    elif selected_algorithm == "A* Algorithm":
        heuristic = {node: 1 for node in graph.vertices}  # Constant heuristic of 1 for all nodes
        return graph.astar(source, destination, heuristic), selected_algorithm

    elif selected_algorithm == "Dijkstra's Algorithm":
        return graph.dijkstra(source, destination), selected_algorithm

    else:
        return graph.bfs(source, destination), selected_algorithm


def main():
    graph = Graph()
    num_edges = int(input("Enter the number of edges: "))
    for i in range(num_edges):
        u, v, weight = input(f"Enter edge {i + 1} (source destination weight): ").split()
        graph.add_edge(u, v, int(weight))
    source = input("Enter the source node: ").lower().strip()
    destination = input("Enter the destination node: ").lower().strip()

    shortest_path, algorithm = evaluate_algorithm(graph, source, destination)
    if shortest_path:
        print("Shortest path:", shortest_path)
        print("Algorithm used:", algorithm)
    else:
        print("No path found between the source and destination nodes.")

if __name__ == "__main__":
    main()



